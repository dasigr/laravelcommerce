<?php namespace Dasigr\Commerce\Exception;

use \Exception;

class InvalidOrderException extends Exception {}
