<?php namespace Dasigr\Commerce\Exception;

use \Exception;

class InvalidRegionException extends Exception {}
