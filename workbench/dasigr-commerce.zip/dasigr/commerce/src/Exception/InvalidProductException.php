<?php namespace Dasigr\Commerce\Exception;

use \Exception;

class InvalidProductException extends Exception {}
